package com.example.myy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle; import android.view.View; import android.widget.Button;
import android.widget.RadioButton; import android.widget.TextView; import android.widget.Toast;

public class MainActivity extends AppCompatActivity { RadioButton java,python,cpp,net,c,php;
    TextView result; Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        java= findViewById(R.id.radioButton1); python= findViewById(R.id.radioButton2); cpp= findViewById(R.id.radioButton3); net= findViewById(R.id.radioButton4);
        c= findViewById(R.id.radioButton5); php= findViewById(R.id.radioButton6); result= findViewById(R.id.textResult); btn= findViewById(R.id.button1);
        btn.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) {
            String selectedCourse = "Selected Course:"; if (java.isChecked()) {
                selectedCourse += "Java";
            }
            if (python.isChecked()) { selectedCourse += "python";
            }
            if (cpp.isChecked()) { selectedCourse += "C++";
            }
            if (net.isChecked()) { selectedCourse += ".net";
            }
            if (c.isChecked()) {
                selectedCourse += "C Programming";
            }
            if (php.isChecked()) { selectedCourse += "PHP";
            }
            result.setText(selectedCourse);
        }

        });
    }

    @SuppressLint("NonConstantResourceId")
    public void onRadioButtonClicked(View view) { boolean checked=((RadioButton)view).isChecked(); String str="";

        switch (view.getId()) {
            case R.id.radioButton1:
                if (checked) {
                    str = "Java Selected";
                }
                break;
            case R.id.radioButton2:
                if (checked) {
                    str = "Python Selected";
                }
                break;
            case R.id.radioButton3:
                if (checked) {
                    str = "C++ Selected";
                }
                break;
            case R.id.radioButton4:
                if (checked) {
                    str = ".Net Selected";
                }
                break;
            case R.id.radioButton5:
                if (checked) {
                    str = "C Programming Selected";
                }
                break;
            case R.id.radioButton6:
                if (checked) {
                    str = "PHP Selected";
                }
                break;
        }

        Toast.makeText(getApplicationContext(),str,Toast.LENGTH_SHORT).show();

    }

}
