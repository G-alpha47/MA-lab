package com.example.greatestthree;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle; import android.view.View; import android.widget.Button; import android.widget.EditText; import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public EditText mEditT1; public EditText mEditT2; public EditText mEditT3; public TextView mResultT4;


    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mEditT1 = findViewById(R.id.editTextNumber1);
        mEditT2= findViewById(R.id.editTextNumber2);
        mEditT3= findViewById(R.id.editTextNumber3);
        mResultT4 = findViewById(R.id.resultView);
        Button mButtonFind = findViewById(R.id.button);
        mButtonFind.setOnClickListener(new View.OnClickListener() { @Override
        public void onClick(View view) {
            if (mEditT1.getText().toString().length() == 0) {
                mEditT1.setText("0");

            }
            if (mEditT2.getText().toString().length() == 0) {
                mEditT2.setText("0");
            }
            if (mEditT3.getText().toString().length() == 0) {
                mEditT3.setText("0");
            }
            int num1 = Integer.parseInt(mEditT1.getText().toString());
            int num2 = Integer.parseInt(mEditT2.getText().toString());
            int num3 = Integer.parseInt(mEditT3.getText().toString());
            int result=((num1>num2)?(Math.max(num1,num3)):(Math.max(num2, num3)));
            mResultT4.setText(String.valueOf(result));
        }
        });

    }

}
